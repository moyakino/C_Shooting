#include "DxLib.h"
#include "Bullet.h"

Bullet::Bullet()
{

}

Bullet::~Bullet()
{

}

void Bullet::Update()
{

}

void Bullet::Draw() const
{

}