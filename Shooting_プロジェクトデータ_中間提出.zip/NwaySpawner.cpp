#include "NwaySpawner.h"

NwaySpawner::NwaySpawner()
{

}

NwaySpawner::~NwaySpawner()
{

}

void NwaySpawner::Shoot(GameMainScene* GameMain)
{

}