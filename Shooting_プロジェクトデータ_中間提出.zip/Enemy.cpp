#include "DxLib.h"
#include "Enemy.h"

Enemy::Enemy()
{

}

Enemy::~Enemy()
{

}

void Enemy::Update(GameMainScene* GameMain)
{

}

void Enemy::Draw()const
{

}

void Enemy::Hit(int damage)
{

}